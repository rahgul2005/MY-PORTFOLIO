import './App.css'
import Counter from './counter/Counter'
function App() {

  return (
    <>
      <Counter></Counter>
    </>
  )
}

export default App